package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.AdminQuestionAnswers;
import com.example.demo.models.Questions;
import com.example.demo.repository.AdminQuestionRepository;
@Service
public class QuestionService {
	
	@Autowired
	private AdminQuestionRepository adminQuestionRepository;
	public QuestionService(AdminQuestionRepository repository)
	{
		this.adminQuestionRepository=repository;
	}

	
	public AdminQuestionAnswers addQuestion(AdminQuestionAnswers question)
	{
		return adminQuestionRepository.save(question);
	}

	public List<AdminQuestionAnswers> addQuestions(List<AdminQuestionAnswers> question)
	{
		return adminQuestionRepository.saveAll(question);
	}
	

}

package com.example.demo.services;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.models.Admin;
import com.example.demo.models.AdminQuestionAnswers;
import com.example.demo.models.QueAns;
import com.example.demo.models.Questions;
import com.example.demo.repository.AdminQuestionRepository;
import com.example.demo.repository.AdminRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;
	
	public AdminService(AdminRepository repository)
	{
		this.adminRepository=repository;
	}

	
	@Autowired
	private QuestionService questionService;
	
	@Autowired
	private AdminQuestionRepository adminQuestionRepository;

	public List<Admin> findadmin() {
		return adminRepository.findAll();
	}
	
	
	public Admin addAdmin(Admin admin) {
		return adminRepository.save(admin);
	}

	public String getAdminPass(String admin_Name) {
		return adminRepository.getAdminPassword(admin_Name);
	}
	
	public String getlogin(String admin_Name) {
		return adminRepository.getAdminPassword(admin_Name);
	}


	public List<QueAns> getQuestions(int adminId) {
		return adminRepository.getAdminQuestions(adminId);
	}
}

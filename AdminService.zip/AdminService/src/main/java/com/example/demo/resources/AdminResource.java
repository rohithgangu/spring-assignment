package com.example.demo.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repository.AdminRepository;
import com.example.demo.services.AdminService;
import com.example.demo.services.QuestionService;

import net.bytebuddy.asm.Advice.OffsetMapping.ForOrigin.Renderer.ForReturnTypeName;

import com.example.demo.models.*;
import java.util.List;
@RestController
public class AdminResource {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private QuestionService questionService;
	
	@GetMapping("/Admin")
	public List<Admin> getAdmin() {
		return adminService.findadmin();
	}
	
	
	@PostMapping("/addAdmin")
	public Admin addAmins(@RequestBody Admin admin) {
		return adminService.addAdmin(admin);
	}
	
	@GetMapping("/Admin/secretQuestions/{adminId}")
	public List<QueAns> getSecQues(@PathVariable int adminId){
		return adminService.getQuestions(adminId);
		
	}
	
	
	@GetMapping("/Adminlogin/{Admin_Name}")
	public String saveAdmin(@PathVariable String Admin_Name) {
		return adminService.getAdminPass(Admin_Name);
	}
	
	@GetMapping("/Adminlogin")
	public String adminLogin(@RequestBody Admin admin) {
		String givenpass= admin.getAdminPassword();
		String correctpass= adminService.getlogin(admin.getAdminName());
		if(givenpass.equals(correctpass)) {
			return "correct password";
		}
		else {
			return "wrong password";
		}
	}
	
	@GetMapping("/ForgotPassword")
	public String adminForgotpassword(@RequestBody Admin admin) {
		return "wait";
	}

}

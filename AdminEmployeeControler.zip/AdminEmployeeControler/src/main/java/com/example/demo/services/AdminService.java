package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Admin;
import com.example.demo.model.Answers;
import com.example.demo.model.QueAns;

import io.netty.handler.codec.http.HttpContentEncoder.Result;

@Service
public class AdminService {

	@Autowired
	private RestTemplate restTemplate;
	
	public ResponseEntity<String> adminLogin(Admin admin) {
		return new ResponseEntity<String>( restTemplate.postForObject("http://localhost:8083/AdminLogin",admin,String.class),HttpStatus.ACCEPTED);
	}

	public ResponseEntity<String> adminRegister(Admin admin) {
		return new ResponseEntity<String>( restTemplate.postForObject("http://localhost:8083/AddAdmin", admin, String.class),HttpStatus.ACCEPTED);
	}

	public List<Admin> getAdmins() {
		return restTemplate.getForObject("http://localhost:8083/Admin",List.class);
	}

	public Admin GetAdminById(int adminId) {
		return restTemplate.getForObject("http://localhost:8083/AdminById/"+adminId, Admin.class);
	}

	//not working
	public Admin addSecQue(int adminId,List<Answers> answers) {
		restTemplate.put("http://localhost:8083/Admin/"+adminId+"/AddQuestions", Admin.class,answers);
		return GetAdminById(adminId);
	}

	/*public ResponseEntity<String> unlockAdmin(QueAns queAns) {
		return restTemplate.put("http://localhost:8083/Admin/"+, queAns);
	}*/
	

}

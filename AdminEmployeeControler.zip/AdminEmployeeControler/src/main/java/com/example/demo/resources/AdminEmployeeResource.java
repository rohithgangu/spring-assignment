package com.example.demo.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Admin;
import com.example.demo.model.Answers;
import com.example.demo.model.QueAns;
import com.example.demo.services.AdminService;

@RestController
@RequestMapping("/EmployeeManagement")
public class AdminEmployeeResource {

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private AdminService adminService;
	
	
	@GetMapping("/Admins")
	public List<Admin> getAdmins(){
		return adminService.getAdmins();
	}
	
	@GetMapping("/AdminById/{adminId}")
	public Admin getAdminById(@PathVariable("adminId")int adminId) {
		return adminService.GetAdminById(adminId);
	}
	
	
	@PostMapping("/Admin/login")
	public ResponseEntity<String> adminLogin(@RequestBody Admin admin) {
		return adminService.adminLogin(admin);
	}
	
	@PostMapping("/Admin/Register")
	public ResponseEntity<String> adminRegister(@RequestBody Admin admin) {
		return adminService.adminRegister(admin);
	}
	
	
	//not working
	@PutMapping("/Admin/{adminId}/AddSecQue")
	public Admin addSecQue(@PathVariable("adminId") int adminId,@RequestBody List<Answers> answers)
	{
		return adminService.addSecQue(adminId,answers);
	}
	
	/*@PutMapping("/Admin/{adminId}/UnlockAccount")
	public ResponseEntity<String> unlockAccount(@PathVariable("adminId") int adminId,@RequestBody QueAns queAns){
		queAns.setAdminId(adminId);
		return adminService.unlockAdmin(queAns);
	}*/
}